# 39 · Evaluación continua — Consumo de APIs REST (JSONPlaceholder)

> Módulo complementario de CiudadAlerta · Aplicaciones Móviles I.
> **API asignada:** API 1 · JSONPlaceholder · `https://jsonplaceholder.typicode.com/posts/1`

## Dónde está el código

| Archivo | Qué hace |
|---|---|
| `app/pubspec.yaml` | Declara `http: ^1.2.2` |
| `app/lib/data/post_api.dart` | Modelo `Post`, `PostApiException` y `PostApiService` (GET + errores) |
| `app/lib/api_prueba_page.dart` | Pantalla con botón de consulta, carga, resultado y error |
| `app/lib/routing/app_router.dart` | Ruta `/api-prueba` |
| `app/lib/screens/reports_list_screen.dart` | Icono ☁ en la barra de Reportes |
| `app/lib/screens/profile_screen.dart` | Opción "Prueba de API REST" en Perfil |
| `app/test/post_api_test.dart` | 10 pruebas con `MockClient` (sin Internet) |
| `scripts/agregar_permiso_internet.sh` | Agrega el permiso INTERNET al `AndroidManifest.xml` |

## Cómo ejecutarlo (Kali Linux)

```bash
unzip CiudadAlerta-*.zip && cd CiudadAlerta-*/
bash scripts/agregar_permiso_internet.sh   # solo agrega el permiso si falta
cd app
flutter pub get                            # resuelve http y demás dependencias
flutter test test/post_api_test.dart       # pruebas del módulo
flutter run                                # emulador o dispositivo Android
```

Dentro de la app: **Perfil → Prueba de API REST** (o el icono ☁ de *Reportes*)
→ **Consultar API**. El botón **Probar error 404** consulta el id 9999 para
demostrar el control de errores.

Si `app/android/` no existe: `cd app && flutter create --platforms=android .`
y vuelve a correr el script.

---

## Actividad 1 · Configuración e instalación de HTTP (20 %)

- `pubspec.yaml` → `dependencies: http: ^1.2.2` (agregado una sola vez).
- `flutter pub get` resuelve las dependencias.
- `AndroidManifest.xml` → dentro de `<manifest>` y **fuera** de `<application>`:
  `<uses-permission android:name="android.permission.INTERNET"/>`
- Importaciones necesarias:

```dart
import 'dart:async';                       // TimeoutException
import 'dart:convert';                     // jsonDecode
import 'package:http/http.dart' as http;   // http.get / http.Client
```

**Explicación.** El paquete `http` permite hacer peticiones HTTP (GET, POST…)
desde Dart. El permiso INTERNET es obligatorio en Android: sin él el sistema
bloquea toda conexión de red de la app, aunque el código sea correcto.

## Actividad 2 · Petición GET (20 %)

`PostApiService.obtenerPost(id)` construye la URL y llama al servicio:

```dart
final url = Uri.parse('https://jsonplaceholder.typicode.com/posts/$id');
final respuesta = await _client.get(url).timeout(timeout);
```

## Actividad 3 · Procesamiento de la respuesta JSON (20 %)

```dart
final datos = jsonDecode(respuesta.body);   // String -> Map<String, dynamic>
return Post.fromJson(datos);                // userId, id, title, body
```

Campos identificados: `userId` (int), `id` (int), `title` (String), `body` (String).
`Post.fromJson` valida que existan y tengan el tipo correcto.

## Actividad 4 · Visualización en Flutter (20 %)

`ApiPruebaPage` muestra los datos reales en una tarjeta (chips de `userId` e
`id`, y los textos `title` y `body`) más un panel desplegable "JSON recibido".
Estados: inicial, cargando, éxito y error.
**Evidencia:** captura de la app corriendo (pendiente de tomar en el emulador).

## Actividad 5 · Control de errores y explicación técnica (20 %)

| Situación | Cómo se controla | Mensaje |
|---|---|---|
| Recurso inexistente (id 9999) | `statusCode == 404` | "El recurso /posts/9999 no existe (404)…" |
| Otro código ≠ 200 | `statusCode != 200` | "El servidor respondió con un error (500)." |
| Sin Internet / DNS | `catch http.ClientException` | "No se pudo conectar…" |
| Servidor no responde | `.timeout(10 s)` → `TimeoutException` | "El servidor tardó demasiado…" |
| JSON roto o sin campos | `catch FormatException` | "La respuesta… no tiene el formato esperado." |
| Id no numérico | Validación local, sin petición | "Escribe un id numérico válido." |

La interfaz **nunca queda cargando**: el `finally` apaga el indicador y el
`timeout` corta esperas largas.

### Explicación técnica individual

- **`http.get()`**: envía una petición HTTP GET a la URL y devuelve un
  `Future<Response>`; el servidor responde con un código, cabeceras y cuerpo.
- **`await`**: pausa solo esa función hasta que el `Future` termina, sin
  congelar la interfaz; solo se usa dentro de funciones `async`.
- **`statusCode`**: número del resultado (200 = OK, 404 = no existe,
  500 = error del servidor). Se revisa **antes** de procesar el cuerpo.
- **`response.body`**: el contenido de la respuesta como `String` (el texto JSON).
- **`jsonDecode()`**: convierte ese texto JSON en un `Map<String, dynamic>`
  para acceder a los campos (`datos['title']`).
- **`try/catch`**: captura fallos (red, timeout, JSON inválido) para mostrar un
  mensaje en vez de cerrar la app.

**Evidencia:** demostrar el botón *Probar error 404* y explicar lo anterior.

---

## Ejecutar en escritorio Linux (Kali)

```bash
bash scripts/preparar_linux.sh   # genera app/linux y parchea el aviso de clang
cd app && flutter run -d linux
```

## Método POST (crear un recurso)

`PostApiService.crearPost()` hace `POST https://jsonplaceholder.typicode.com/posts`
con cabecera `Content-Type: application/json` y cuerpo `jsonEncode({title, body, userId})`.
JSONPlaceholder simula la creación y responde **201 Created** con el JSON enviado
más un `id` nuevo (101). En la app: pantalla *Prueba de API REST* → sección
"Método POST" → **Enviar POST**.
