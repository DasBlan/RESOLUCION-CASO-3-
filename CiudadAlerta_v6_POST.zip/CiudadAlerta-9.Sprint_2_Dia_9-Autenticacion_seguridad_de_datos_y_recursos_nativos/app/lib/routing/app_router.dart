// CiudadAlerta - Configuracion de navegacion (Clase 4 / Dia 4)
//
// HU-02: "Como usuario quiero navegar por pestañas (Inicio, Mapa, Nuevo,
// Perfil) para llegar rápido a cada sección".
//
// go_router reemplaza la navegación manual con Navigator.push:
//   - Rutas declarativas: cada pantalla tiene una URL (/inicio, /nuevo...).
//   - Parámetros: /reporte/:id (HU-04) recibe el id en la ruta misma.
//   - StatefulShellRoute: el shell con barra inferior conserva el estado
//     de cada pestaña (IndexedStack): si vuelves a Inicio, la lista sigue
//     donde la dejaste.
//
// Mapa de rutas del Dia 4 (+ Dia 8 + Dia 9):
//   /                 -> WelcomeScreen (HU-01; Dia 9: autentica HU-08)
//   /registro         -> RegisterScreen (HU-08, Dia 9: crear cuenta)
//   /inicio           -> ReportsListScreen   (pestaña 1, HU-03/HU-09)
//   /mapa             -> MapPlaceholderScreen(pestaña 2, HU-14 en Sprint 3)
//   /nuevo            -> NewReportScreen     (pestaña 3, HU-05/HU-10/HU-11)
//   /perfil           -> ProfileScreen       (pestaña 4; Dia 9: sesion real)
//   /reporte/:id      -> ReportDetailScreen  (HU-04, fuera del shell)
//   /editar/:id       -> NewReportScreen modo edicion (HU-10, Dia 8)
//   /estadisticas     -> StatsScreen         (HU-13, Dia 8: GROUP BY + fl_chart)
//   /api-prueba       -> ApiPruebaPage       (Evaluacion continua: API REST JSONPlaceholder)

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../api_prueba_page.dart';
import '../screens/home_shell.dart';
import '../screens/map_placeholder_screen.dart';
import '../screens/new_report_screen.dart';
import '../screens/profile_screen.dart';
import '../screens/register_screen.dart';
import '../screens/report_detail_screen.dart';
import '../screens/reports_list_screen.dart';
import '../screens/stats_screen.dart';
import '../screens/welcome_screen.dart';

final appRouter = GoRouter(
  initialLocation: '/',
  routes: [
    // HU-01: bienvenida e inicio de sesion (fuera del shell: pantalla completa)
    GoRoute(
      path: '/',
      name: 'bienvenida',
      builder: (context, state) => const WelcomeScreen(),
    ),

    // HU-08 (Dia 9): registro de cuenta (fuera del shell)
    GoRoute(
      path: '/registro',
      name: 'registro',
      builder: (context, state) => const RegisterScreen(),
    ),

    // HU-02: shell con barra de navegacion inferior de 4 pestañas
    StatefulShellRoute.indexedStack(
      builder: (context, state, navigationShell) => HomeShell(shell: navigationShell),
      branches: [
        StatefulShellBranch(
          routes: [
            GoRoute(
              path: '/inicio',
              name: 'inicio',
              builder: (context, state) => const ReportsListScreen(),
            ),
          ],
        ),
        StatefulShellBranch(
          routes: [
            GoRoute(
              path: '/mapa',
              name: 'mapa',
              builder: (context, state) => const MapPlaceholderScreen(),
            ),
          ],
        ),
        StatefulShellBranch(
          routes: [
            GoRoute(
              path: '/nuevo',
              name: 'nuevo',
              builder: (context, state) => const NewReportScreen(),
            ),
          ],
        ),
        StatefulShellBranch(
          routes: [
            GoRoute(
              path: '/perfil',
              name: 'perfil',
              builder: (context, state) => const ProfileScreen(),
            ),
          ],
        ),
      ],
    ),

    // HU-04: detalle de reporte con PARAMETRO de ruta (:id)
    GoRoute(
      path: '/reporte/:id',
      name: 'detalle',
      builder: (context, state) {
        final id = state.pathParameters['id'] ?? '';
        return ReportDetailScreen(id: id);
      },
    ),

    // HU-10 (Dia 8): edicion reutilizando el formulario con modo edicion
    GoRoute(
      path: '/editar/:id',
      name: 'editar',
      builder: (context, state) {
        final id = state.pathParameters['id'] ?? '';
        return NewReportScreen(codigo: id);
      },
    ),

    // HU-13 (Dia 8): estadisticas GROUP BY + grafico fl_chart
    GoRoute(
      path: '/estadisticas',
      name: 'estadisticas',
      builder: (context, state) => const StatsScreen(),
    ),

    // Evaluacion continua: consumo de API REST (JSONPlaceholder, API 1)
    GoRoute(
      path: '/api-prueba',
      name: 'apiPrueba',
      builder: (context, state) => const ApiPruebaPage(),
    ),
  ],
);
