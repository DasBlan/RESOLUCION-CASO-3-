// CiudadAlerta - Modulo de consulta a una API REST externa (Evaluacion continua)
//
// API asignada: JSONPlaceholder  ->  https://jsonplaceholder.typicode.com/posts/1
//
// Este archivo concentra TODO lo relacionado con la red (regla de capas del
// Dia 6: la pantalla no sabe de HTTP; pide un Post al servicio):
//
//   Post             -> modelo con los 4 campos del JSON (userId, id, title, body)
//   PostApiException -> error con mensaje legible para el usuario
//   PostApiService   -> hace el http.get(), valida statusCode y decodifica el JSON
//
// ACTIVIDAD 1: importaciones necesarias -> dart:async, dart:convert y
//              package:http/http.dart as http.
// ACTIVIDAD 2: peticion GET   -> _client.get(url)
// ACTIVIDAD 3: JSON           -> jsonDecode(respuesta.body) y Post.fromJson
// ACTIVIDAD 5: errores        -> try/catch + statusCode + timeout

import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

/// Direccion base del servicio asignado (API 1).
const String urlBaseJsonPlaceholder = 'https://jsonplaceholder.typicode.com';

// ---------------------------------------------------------------------------
// Modelo (Actividad 3): los campos del JSON de /posts/1
//
//   {
//     "userId": 1,
//     "id": 1,
//     "title": "sunt aut facere repellat ...",
//     "body": "quia et suscipit ..."
//   }
// ---------------------------------------------------------------------------
class Post {
  const Post({
    required this.userId,
    required this.id,
    required this.title,
    required this.body,
  });

  final int userId;
  final int id;
  final String title;
  final String body;

  /// Convierte el Map que entrega jsonDecode() en un objeto Post.
  /// Si falta un campo o tiene otro tipo, lanza FormatException (se captura
  /// en el servicio y se muestra como "respuesta inesperada").
  factory Post.fromJson(Object? json) {
    if (json is! Map<String, dynamic>) {
      throw const FormatException('El JSON no es un objeto');
    }
    final userId = json['userId'];
    final id = json['id'];
    final title = json['title'];
    final body = json['body'];
    if (userId is! int || id is! int || title is! String || body is! String) {
      throw const FormatException('Faltan campos o tienen un tipo distinto');
    }
    return Post(userId: userId, id: id, title: title, body: body);
  }

  Map<String, dynamic> toJson() =>
      {'userId': userId, 'id': id, 'title': title, 'body': body};
}

// ---------------------------------------------------------------------------
// Error propio con un mensaje que SI se puede mostrar al ciudadano.
// ---------------------------------------------------------------------------
class PostApiException implements Exception {
  const PostApiException(this.mensaje, {this.statusCode});

  final String mensaje;
  final int? statusCode;

  @override
  String toString() => mensaje;
}

// ---------------------------------------------------------------------------
// Servicio HTTP
// ---------------------------------------------------------------------------
class PostApiService {
  /// [client] se puede inyectar (los tests usan MockClient, sin red real).
  PostApiService({
    http.Client? client,
    this.baseUrl = urlBaseJsonPlaceholder,
    this.timeout = const Duration(seconds: 10),
  }) : _client = client ?? http.Client();

  final http.Client _client;
  final String baseUrl;

  /// Tiempo maximo de espera: evita que la interfaz quede cargando para siempre.
  final Duration timeout;

  /// GET {baseUrl}/posts/{id}
  Future<Post> obtenerPost(int id) => _protegido(() async {
        // 1) Construir la URL del servicio
        final url = Uri.parse('$baseUrl/posts/$id');

        // 2) Solicitud HTTP. await pausa ESTA funcion hasta que llegue la
        //    respuesta (la app sigue fluida); timeout corta la espera.
        final respuesta = await _client.get(url).timeout(timeout);

        // 3) Verificar statusCode ANTES de procesar el cuerpo
        if (respuesta.statusCode == 404) {
          throw PostApiException(
            'El recurso /posts/$id no existe (404). Prueba con un id entre 1 y 100.',
            statusCode: 404,
          );
        }
        if (respuesta.statusCode != 200) {
          throw PostApiException(
            'El servidor respondio con un error (${respuesta.statusCode}).',
            statusCode: respuesta.statusCode,
          );
        }

        // 4) Conversion de JSON (String) a Map y luego al modelo
        return Post.fromJson(jsonDecode(respuesta.body));
      });

  /// POST {baseUrl}/posts  -> crea un recurso (JSONPlaceholder lo simula y
  /// responde 201 Created con el mismo JSON mas un id nuevo, normalmente 101).
  Future<Post> crearPost({
    required String title,
    required String body,
    int userId = 1,
  }) =>
      _protegido(() async {
        final url = Uri.parse('$baseUrl/posts');

        // El cuerpo viaja como JSON: jsonEncode convierte el Map en texto
        // y la cabecera Content-Type avisa al servidor del formato.
        final respuesta = await _client
            .post(
              url,
              headers: {'Content-Type': 'application/json; charset=UTF-8'},
              body: jsonEncode({'title': title, 'body': body, 'userId': userId}),
            )
            .timeout(timeout);

        // 201 = Created (200 tambien se acepta por compatibilidad)
        if (respuesta.statusCode != 201 && respuesta.statusCode != 200) {
          throw PostApiException(
            'No se pudo crear el recurso (${respuesta.statusCode}).',
            statusCode: respuesta.statusCode,
          );
        }
        return Post.fromJson(jsonDecode(respuesta.body));
      });

  /// Traduce cualquier fallo tecnico a un PostApiException con mensaje claro.
  Future<T> _protegido<T>(Future<T> Function() accion) async {
    try {
      return await accion();
    } on PostApiException {
      rethrow; // ya trae un mensaje listo para la UI
    } on TimeoutException {
      throw const PostApiException(
        'El servidor tardo demasiado en responder. Intenta de nuevo.',
      );
    } on http.ClientException {
      // Sin Internet, DNS que falla, conexion rechazada, etc.
      throw const PostApiException(
        'No se pudo conectar. Revisa tu conexion a Internet.',
      );
    } on FormatException {
      // jsonDecode fallo o el JSON no tiene los campos esperados
      throw const PostApiException(
        'La respuesta del servidor no tiene el formato esperado.',
      );
    } catch (_) {
      throw const PostApiException('Ocurrio un error inesperado.');
    }
  }

  /// Libera el cliente HTTP (llamar al destruir la pantalla que lo creo).
  void cerrar() => _client.close();
}
