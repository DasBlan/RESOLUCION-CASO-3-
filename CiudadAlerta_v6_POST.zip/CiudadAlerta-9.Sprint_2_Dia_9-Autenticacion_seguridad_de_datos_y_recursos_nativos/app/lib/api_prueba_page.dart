// CiudadAlerta - Pantalla de prueba de la API REST (Evaluacion continua)
//
// Modulo complementario: consulta JSONPlaceholder (API 1) y muestra el post.
//   Ruta: /api-prueba   (acceso desde Reportes y desde Perfil)
//
// Estados de la pantalla (Actividades 4 y 5):
//   - inicial   : instrucciones + boton "Consultar API"
//   - cargando  : CircularProgressIndicator (siempre termina: hay timeout)
//   - exito     : tarjeta con userId, id, title y body + JSON recibido
//   - error     : tarjeta roja con el mensaje (404, sin red, timeout, JSON malo)
//
// La pantalla NO hace http.get(): le pide el Post a PostApiService
// (lib/data/post_api.dart), igual que las demas pantallas piden al repositorio.

import 'dart:convert';

import 'package:flutter/material.dart';

import 'data/post_api.dart';

class ApiPruebaPage extends StatefulWidget {
  const ApiPruebaPage({super.key, this.servicio});

  /// Inyectable para pruebas; en la app real se crea el servicio por defecto.
  final PostApiService? servicio;

  @override
  State<ApiPruebaPage> createState() => _ApiPruebaPageState();
}

class _ApiPruebaPageState extends State<ApiPruebaPage> {
  late final PostApiService _servicio = widget.servicio ?? PostApiService();
  final _idCtrl = TextEditingController(text: '1');
  final _tituloCtrl = TextEditingController(text: 'Bache en Av. Buenos Aires');
  final _cuerpoCtrl =
      TextEditingController(text: 'Reporte ciudadano enviado desde CiudadAlerta');
  String? _etiqueta; // que operacion produjo el resultado (GET / POST)

  bool _cargando = false;
  Post? _reporte; // el post recibido (nombre del paso 6 de la guia)
  String? _error;

  @override
  void dispose() {
    _idCtrl.dispose();
    _tituloCtrl.dispose();
    _cuerpoCtrl.dispose();
    // Solo cerramos el cliente si lo creamos nosotros
    if (widget.servicio == null) _servicio.cerrar();
    super.dispose();
  }

  Future<void> _consultar() async {
    FocusScope.of(context).unfocus();

    // Validacion local antes de gastar una peticion
    final id = int.tryParse(_idCtrl.text.trim());
    if (id == null || id < 0) {
      setState(() {
        _reporte = null;
        _error = 'Escribe un id numerico valido (por ejemplo 1).';
      });
      return;
    }

    setState(() {
      _cargando = true;
      _error = null;
      _reporte = null;
      _etiqueta = null;
    });

    try {
      final post = await _servicio.obtenerPost(id);
      if (!mounted) return;
      setState(() {
        _reporte = post;
        _etiqueta = 'GET /posts/$id  ->  200 OK';
      });
    } on PostApiException catch (e) {
      if (!mounted) return;
      setState(() => _error = e.mensaje);
    } catch (_) {
      if (!mounted) return;
      setState(() => _error = 'Ocurrio un error inesperado.');
    } finally {
      // Pase lo que pase, el indicador de carga se apaga
      if (mounted) setState(() => _cargando = false);
    }
  }

  /// POST: envia un recurso nuevo al servidor y muestra lo que responde.
  Future<void> _enviarPost() async {
    FocusScope.of(context).unfocus();
    final titulo = _tituloCtrl.text.trim();
    final cuerpo = _cuerpoCtrl.text.trim();
    if (titulo.isEmpty || cuerpo.isEmpty) {
      setState(() {
        _reporte = null;
        _etiqueta = null;
        _error = 'Completa el titulo y el cuerpo antes de enviar.';
      });
      return;
    }
    setState(() {
      _cargando = true;
      _error = null;
      _reporte = null;
      _etiqueta = null;
    });
    try {
      final creado = await _servicio.crearPost(title: titulo, body: cuerpo);
      if (!mounted) return;
      setState(() {
        _reporte = creado;
        _etiqueta = 'POST /posts  ->  201 Created (id asignado: ${creado.id})';
      });
    } on PostApiException catch (e) {
      if (!mounted) return;
      setState(() => _error = e.mensaje);
    } catch (_) {
      if (!mounted) return;
      setState(() => _error = 'Ocurrio un error inesperado.');
    } finally {
      if (mounted) setState(() => _cargando = false);
    }
  }

  void _probarError() {
    _idCtrl.text = '9999'; // JSONPlaceholder responde 404 a este id
    _consultar();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('API REST · JSONPlaceholder')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(
            'GET $urlBaseJsonPlaceholder/posts/{id}',
            style: theme.textTheme.bodySmall?.copyWith(
              fontFamily: 'monospace',
              color: theme.colorScheme.outline,
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _idCtrl,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(
              labelText: 'Id del post',
              prefixIcon: Icon(Icons.tag),
            ),
            onSubmitted: (_) => _consultar(),
          ),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: _cargando ? null : _consultar,
            icon: const Icon(Icons.cloud_download_outlined),
            label: const Text('Consultar API'),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: _cargando ? null : _probarError,
            icon: const Icon(Icons.bug_report_outlined),
            label: const Text('Probar error 404 (id 9999)'),
          ),
          const Divider(height: 32),
          Text('Metodo POST (crear un recurso)',
              style: theme.textTheme.titleSmall),
          const SizedBox(height: 8),
          TextField(
            controller: _tituloCtrl,
            decoration: const InputDecoration(
              labelText: 'title',
              prefixIcon: Icon(Icons.title),
            ),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _cuerpoCtrl,
            decoration: const InputDecoration(
              labelText: 'body',
              prefixIcon: Icon(Icons.notes),
            ),
          ),
          const SizedBox(height: 8),
          FilledButton.tonalIcon(
            onPressed: _cargando ? null : _enviarPost,
            icon: const Icon(Icons.cloud_upload_outlined),
            label: const Text('Enviar POST'),
          ),
          const SizedBox(height: 20),
          if (_etiqueta != null && !_cargando && _error == null)
            Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Text(
                _etiqueta!,
                style: theme.textTheme.labelLarge?.copyWith(
                  fontFamily: 'monospace',
                  color: theme.colorScheme.primary,
                ),
              ),
            ),
          _resultado(theme),
        ],
      ),
    );
  }

  Widget _resultado(ThemeData theme) {
    if (_cargando) {
      return const Padding(
        padding: EdgeInsets.all(24),
        child: Center(child: CircularProgressIndicator()),
      );
    }
    if (_error != null) {
      return Card(
        color: theme.colorScheme.errorContainer,
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(Icons.error_outline, color: theme.colorScheme.onErrorContainer),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  _error!,
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: theme.colorScheme.onErrorContainer,
                  ),
                ),
              ),
            ],
          ),
        ),
      );
    }
    final post = _reporte;
    if (post == null) {
      return Text(
        'Pulsa "Consultar API" para pedir un post al servicio.',
        style: theme.textTheme.bodyMedium,
        textAlign: TextAlign.center,
      );
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Wrap(
                  spacing: 8,
                  children: [
                    Chip(label: Text('userId: ${post.userId}')),
                    Chip(label: Text('id: ${post.id}')),
                  ],
                ),
                const SizedBox(height: 12),
                Text('title', style: theme.textTheme.labelMedium),
                Text(post.title, style: theme.textTheme.titleMedium),
                const SizedBox(height: 12),
                Text('body', style: theme.textTheme.labelMedium),
                Text(post.body, style: theme.textTheme.bodyMedium),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        ExpansionTile(
          title: const Text('JSON recibido'),
          children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: SelectableText(
                const JsonEncoder.withIndent('  ').convert(post.toJson()),
                style: theme.textTheme.bodySmall?.copyWith(fontFamily: 'monospace'),
              ),
            ),
          ],
        ),
      ],
    );
  }
}
