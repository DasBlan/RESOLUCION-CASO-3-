// CiudadAlerta - Pruebas del modulo API REST (JSONPlaceholder)
// Evaluacion continua: Actividades 2, 3, 4 y 5.
//
// Se usa MockClient (package:http/testing.dart): simula las respuestas del
// servidor SIN usar Internet, asi las pruebas son rapidas y repetibles.
//
// Comando: flutter test test/post_api_test.dart

import 'dart:async';
import 'dart:convert';

import 'package:ciudadalerta/api_prueba_page.dart';
import 'package:ciudadalerta/data/post_api.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';

const _postJson = {
  'userId': 1,
  'id': 1,
  'title': 'sunt aut facere repellat',
  'body': 'quia et suscipit',
};

PostApiService _servicio(Future<http.Response> Function(http.Request) h,
        {Duration timeout = const Duration(seconds: 2)}) =>
    PostApiService(client: MockClient(h), timeout: timeout);

void main() {
  group('PostApiService (Actividades 2, 3 y 5)', () {
    test('GET exitoso: pide /posts/1 y decodifica los 4 campos', () async {
      late Uri pedida;
      final servicio = _servicio((req) async {
        pedida = req.url;
        return http.Response(jsonEncode(_postJson), 200);
      });
      final post = await servicio.obtenerPost(1);
      expect(pedida.toString(), 'https://jsonplaceholder.typicode.com/posts/1');
      expect(post.userId, 1);
      expect(post.id, 1);
      expect(post.title, 'sunt aut facere repellat');
      expect(post.body, 'quia et suscipit');
    });

    test('POST: envia JSON a /posts y recibe 201 con id nuevo', () async {
      late http.Request recibida;
      final servicio = _servicio((req) async {
        recibida = req;
        return http.Response(
          jsonEncode({'userId': 1, 'id': 101, 'title': 'T', 'body': 'B'}),
          201,
        );
      });
      final creado = await servicio.crearPost(title: 'T', body: 'B');
      expect(recibida.method, 'POST');
      expect(recibida.url.path, '/posts');
      expect(jsonDecode(recibida.body)['title'], 'T');
      expect(recibida.headers['Content-Type'], contains('application/json'));
      expect(creado.id, 101);
    });

    test('POST con error del servidor -> PostApiException', () async {
      final servicio = _servicio((_) async => http.Response('x', 500));
      expect(servicio.crearPost(title: 'T', body: 'B'),
          throwsA(isA<PostApiException>()));
    });

    test('404: recurso inexistente -> mensaje claro', () async {
      final servicio = _servicio((_) async => http.Response('{}', 404));
      expect(
        servicio.obtenerPost(9999),
        throwsA(isA<PostApiException>()
            .having((e) => e.statusCode, 'statusCode', 404)
            .having((e) => e.mensaje, 'mensaje', contains('no existe'))),
      );
    });

    test('500: error del servidor', () async {
      final servicio = _servicio((_) async => http.Response('x', 500));
      expect(
        servicio.obtenerPost(1),
        throwsA(isA<PostApiException>()
            .having((e) => e.statusCode, 'statusCode', 500)),
      );
    });

    test('JSON invalido -> formato inesperado (no se cae la app)', () async {
      final servicio = _servicio((_) async => http.Response('no es json', 200));
      expect(
        servicio.obtenerPost(1),
        throwsA(isA<PostApiException>()
            .having((e) => e.mensaje, 'mensaje', contains('formato'))),
      );
    });

    test('JSON sin los campos esperados -> formato inesperado', () async {
      final servicio =
          _servicio((_) async => http.Response('{"id": 1}', 200));
      expect(servicio.obtenerPost(1), throwsA(isA<PostApiException>()));
    });

    test('sin Internet (ClientException) -> mensaje de conexion', () async {
      final servicio =
          _servicio((_) async => throw http.ClientException('sin red'));
      expect(
        servicio.obtenerPost(1),
        throwsA(isA<PostApiException>()
            .having((e) => e.mensaje, 'mensaje', contains('conectar'))),
      );
    });

    test('timeout: no queda cargando indefinidamente', () async {
      final servicio = _servicio(
        (_) => Completer<http.Response>().future, // nunca responde
        timeout: const Duration(milliseconds: 50),
      );
      expect(
        servicio.obtenerPost(1),
        throwsA(isA<PostApiException>()
            .having((e) => e.mensaje, 'mensaje', contains('tardo'))),
      );
    });
  });

  group('ApiPruebaPage (Actividades 4 y 5)', () {
    Widget app(PostApiService s) =>
        MaterialApp(home: ApiPruebaPage(servicio: s));

    testWidgets('muestra userId, id, title y body tras consultar',
        (tester) async {
      await tester.pumpWidget(app(
        _servicio((_) async => http.Response(jsonEncode(_postJson), 200)),
      ));
      expect(find.text('Consultar API'), findsOneWidget);

      await tester.tap(find.text('Consultar API'));
      await tester.pumpAndSettle();

      expect(find.text('userId: 1'), findsOneWidget);
      expect(find.text('id: 1'), findsOneWidget);
      expect(find.text('sunt aut facere repellat'), findsOneWidget);
      expect(find.text('quia et suscipit'), findsOneWidget);
    });

    testWidgets('boton Enviar POST muestra el 201 y el id creado',
        (tester) async {
      await tester.pumpWidget(app(_servicio((req) async {
        expect(req.method, 'POST');
        return http.Response(
          jsonEncode({'userId': 1, 'id': 101, 'title': 'T', 'body': 'B'}),
          201,
        );
      })));
      await tester.scrollUntilVisible(find.text('Enviar POST'), 200,
          scrollable: find.byType(Scrollable).first);
      await tester.tap(find.text('Enviar POST'));
      await tester.pumpAndSettle();
      expect(find.textContaining('201 Created'), findsOneWidget);
      expect(find.text('id: 101'), findsOneWidget);
    });

    testWidgets('id inexistente muestra el error y apaga la carga',
        (tester) async {
      await tester.pumpWidget(app(
        _servicio((_) async => http.Response('{}', 404)),
      ));

      await tester.tap(find.text('Probar error 404 (id 9999)'));
      await tester.pumpAndSettle();

      expect(find.textContaining('no existe'), findsOneWidget);
      expect(find.byType(CircularProgressIndicator), findsNothing);
    });

    testWidgets('id no numerico: valida sin hacer la peticion',
        (tester) async {
      var llamadas = 0;
      await tester.pumpWidget(app(_servicio((_) async {
        llamadas++;
        return http.Response('{}', 200);
      })));

      await tester.enterText(find.byType(TextField), 'abc');
      await tester.tap(find.text('Consultar API'));
      await tester.pumpAndSettle();

      expect(llamadas, 0);
      expect(find.textContaining('id numerico'), findsOneWidget);
    });
  });
}
