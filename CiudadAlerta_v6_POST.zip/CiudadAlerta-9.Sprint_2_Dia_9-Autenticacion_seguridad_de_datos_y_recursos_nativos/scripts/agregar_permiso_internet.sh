#!/usr/bin/env bash
# CiudadAlerta - Evaluacion continua (Actividad 1)
# Agrega <uses-permission android:name="android.permission.INTERNET"/> al
# AndroidManifest.xml SOLO si todavia no esta (idempotente).
#
# Uso (desde la raiz del repositorio, en Kali/Linux):
#   bash scripts/agregar_permiso_internet.sh
set -euo pipefail

MANIFEST="app/android/app/src/main/AndroidManifest.xml"

if [ ! -f "$MANIFEST" ]; then
  echo "No existe $MANIFEST (la carpeta android/ aun no se genero)."
  echo "Ejecuta primero:"
  echo "  cd app && flutter create --platforms=android . && cd .."
  echo "y luego vuelve a correr este script."
  exit 1
fi

if grep -q 'android.permission.INTERNET' "$MANIFEST"; then
  echo "OK: el permiso INTERNET ya esta declarado en $MANIFEST"
  exit 0
fi

python3 - "$MANIFEST" <<'PY'
import re, sys
ruta = sys.argv[1]
txt = open(ruta, encoding="utf-8").read()
permiso = '    <uses-permission android:name="android.permission.INTERNET"/>'
# justo despues de la etiqueta de apertura <manifest ...>, fuera de <application>
nuevo, n = re.subn(r'(<manifest[^>]*>)', lambda m: m.group(1) + "\n" + permiso, txt, count=1)
if n != 1:
    sys.exit("No se encontro la etiqueta <manifest> en " + ruta)
open(ruta, "w", encoding="utf-8").write(nuevo)
print("Permiso INTERNET agregado en " + ruta)
PY
