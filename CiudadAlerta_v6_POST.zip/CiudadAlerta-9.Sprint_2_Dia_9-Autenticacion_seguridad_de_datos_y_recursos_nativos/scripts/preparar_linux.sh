#!/usr/bin/env bash
# CiudadAlerta - Prepara la version de escritorio Linux (para correr en la PC).
#  1) genera app/linux si no existe (flutter create --platforms=linux .)
#  2) desactiva el aviso -Wdeprecated-literal-operator que el clang nuevo de
#     Kali convierte en error al compilar flutter_secure_storage_linux
# Es idempotente. Uso (desde la raiz del repositorio):  bash scripts/preparar_linux.sh
set -euo pipefail
cd "$(dirname "$0")/../app"

[ -d linux ] || flutter create --platforms=linux .

CM="linux/CMakeLists.txt"
if grep -q 'Wno-deprecated-literal-operator' "$CM"; then
  echo "OK: $CM ya esta parcheado"
else
  python3 - "$CM" <<'PY'
import re, sys
p = sys.argv[1]
s = open(p, encoding="utf-8").read()
linea = "add_compile_options(-Wno-deprecated-literal-operator)  # clang nuevo + json.hpp del plugin"
s, n = re.subn(r'(^project\([^\n]*\n)', lambda m: m.group(1) + linea + "\n", s, count=1, flags=re.M)
if n != 1:
    sys.exit("No se encontro project(...) en " + p)
open(p, "w", encoding="utf-8").write(s)
print("Parche aplicado en " + p)
PY
fi
flutter clean >/dev/null
flutter pub get
echo "Listo. Ejecuta:  cd app && flutter run -d linux"
